package demo;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.codec.binary.Base64;

public class Test {
	
	private static final String PRIVKEY = "E:\\eclipse\\workspace\\RsaDemo\\src\\demo\\privkey.der";
//	private static final String PUBKEY = "E:\\eclipse\\workspace\\RsaDemo\\src\\demo\\pubkey.der";
	
    //数字签名，密钥算法  
    public static final String KEY_ALGORITHM="RSA";  
      
    /** 
     * 数字签名 
     * 签名/验证算法 
     * */  
    public static final String SIGNATURE_ALGORITHM="SHA1withRSA";  
      
    /** 
     * RSA密钥长度，RSA算法的默认密钥长度是1024 
     * 密钥长度必须是64的倍数，在512到65536位之间 
     * */  
    private static final int KEY_SIZE=512;  	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {		
		
		String str = "这是一个RSA数字签名小程序";  
	    
	    System.out.println("原文:"+str);  
	    
	    byte[] privKeyBytes = getPrivateKey();
//	    byte[] pubKeyBytes = getPublicKey();
	    System.out.println("私钥："+Base64.encodeBase64String(privKeyBytes)); 
	    
	    byte[] signBytes = sign(str.getBytes(), privKeyBytes);
	    
	    

	    System.out.println("产生签名："+java.net.URLEncoder.encode(Base64.encodeBase64String(signBytes),   "utf-8"));
	    
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    Date d = sdf.parse("1970-01-01 00:00:01");
	    long t = (System.currentTimeMillis() - d.getTime()) / 1000; 
	    
	    
	    System.out.println("时间差值差值:\t" + t);
//	    boolean status = verify(str.getBytes(), pubKeyBytes, signBytes);  
//        System.out.println("状态："+status+"/n/n");  
	    
	    
	    
	    

	}
	
    /** 
     * 取得私钥 
     * @param keyMap 密钥map 
     * @return byte[] 私钥 
     * */  
    private static byte[] getPrivateKey(){  
	    File privKeyFile = new File(PRIVKEY);  
	    FileInputStream fis = null;
	    DataInputStream dis = null;
	    try {
	    	fis = new FileInputStream(privKeyFile);
	    	dis = new DataInputStream(fis);  
	    	byte[] privKeyBytes = new byte[(int) privKeyFile.length()];  
		    dis.read(privKeyBytes);  
		    return privKeyBytes;
	    }catch(IOException e) {
	    	e.printStackTrace();
	    }finally {
		    try {
				dis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}  
	    }
	    
	    return null;
	    
	    
    }  
    /** 
     * 取得公钥 
     * @param keyMap 密钥map 
     * @return byte[] 公钥 
     * */  
//    private static byte[] getPublicKey() {  
//	    File pubKeyFile = new File(PUBKEY);  
//
//	    
//	    
//	    FileInputStream fis = null;
//	    DataInputStream dis = null;
//	    try {
//	    	fis = new FileInputStream(pubKeyFile);
//	    	dis = new DataInputStream(fis);  
//	    	
//	    	byte[] pubKeyBytes = new byte[(int) pubKeyFile.length()];  
//		    dis.read(pubKeyBytes);  
//		    return pubKeyBytes;
//	    }catch(Exception ex) {
//	    	ex.printStackTrace();
//	    }finally {
//		    try {
//				dis.close();
//			} catch (IOException e) {
//				e.printStackTrace();
//			}  
//	    }
//	    return null;
//    }  
	
    /** 
     * 签名 
     * @param data待签名数据 
     * @param privateKey 密钥 
     * @return byte[] 数字签名 
     * */  
    public static byte[] sign(byte[] data,byte[] privateKey) throws Exception{  
          
        //取得私钥  
        PKCS8EncodedKeySpec pkcs8KeySpec=new PKCS8EncodedKeySpec(privateKey);  
        KeyFactory keyFactory=KeyFactory.getInstance(KEY_ALGORITHM);  
        //生成私钥  
        PrivateKey priKey=keyFactory.generatePrivate(pkcs8KeySpec);  
        //实例化Signature  
        Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);  
        //初始化Signature  
        signature.initSign(priKey);  
        //更新  
        signature.update(data);  
        return signature.sign();  
    }  	
	
    /** 
     * 校验数字签名 
     * @param data 待校验数据 
     * @param publicKey 公钥 
     * @param sign 数字签名 
     * @return boolean 校验成功返回true，失败返回false 
     * */  
    public static boolean verify(byte[] data,byte[] publicKey,byte[] sign) throws Exception{  
        //转换公钥材料  
        //实例化密钥工厂  
        KeyFactory keyFactory=KeyFactory.getInstance(KEY_ALGORITHM);  
        //初始化公钥  
        //密钥材料转换  
        X509EncodedKeySpec x509KeySpec=new X509EncodedKeySpec(publicKey);  
        
        //产生公钥  
        PublicKey pubKey=keyFactory.generatePublic(x509KeySpec);  
        //实例化Signature  
        Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);  
        //初始化Signature  
        signature.initVerify(pubKey);  
        //更新  
        signature.update(data);  
        //验证  
        return signature.verify(sign);  
    }  

}
